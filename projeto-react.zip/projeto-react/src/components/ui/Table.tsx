interface Props {
  columns: string[];
  data: (string | number | React.ReactNode)[][];
}

export const Table = (props: Props) => {
  return (
    <div className="flex flex-col">
      <div className="overflow-x-auto sm:mx-0.5 lg:mx-0.5">
        <div className="py-2 inline-block min-w-full">
          <div className="overflow-hidden">
            <table className="min-w-full">
              <thead className="bg-gray-200 border-b">
                <tr>
                  {props.columns.map((column, index) => (
                    <th
                      scope="col"
                      className={"text-sm font-medium text-gray-900 px-6 py-4 text-left" + (index === props.columns.length - 1 ? " text-end" : "")}
                    >
                      {column}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {props.data.map(row => (
                  <tr className="bg-white border-b transition duration-300 ease-in-out hover:bg-gray-100">
                    {row.map(cell => (
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-light text-gray-900">
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
