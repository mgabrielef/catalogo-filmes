import axios from "axios";
import { Table } from "./ui/Table";
import { Button } from "./ui/Button";
import { Filme } from "../App";
import { useEffect, useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { useToast } from "./ui/use-toast";

interface Props {
  carregarFilmes: () => Promise<void>;
  filmes: Filme[];
  editarFilme: (filme: Filme) => void;
}

export const ListarFilmes = (props: Props) => {
  const [carregando, setCarregando] = useState(false);
  const { toast } = useToast()

  const handleRemoverFilme = async (id: number) => {
    setCarregando(true);
    try {
      await axios.delete(`http://localhost:5000/filmes/${id}`);
      toast({
        title: 'Filme removido com sucesso!',
      })
      props.carregarFilmes();
    } catch (error) {
      console.error(`Erro ao remover filme ${id}:`, error);
    } finally {
      setCarregando(false);
    }
  };

  useEffect(() => {
    props.carregarFilmes();
  }, [])

  return (
    <div className="flex flex-col w-full">
      {props.filmes && (
        <Table 
          columns={["Titulo", "Ator", "Faixa Etaria", "Genero", "Ação"]}
          data={props.filmes.map((f) => [
            f.titulo,
            f.ator,
            f.faixaEtaria,
            f.genero,
            <div className="flex gap-2 flex-1">
              <Button 
                className="ml-auto"
                disabled={carregando}
                variant="destructive"
                size={'sm'}
                aria-label="Remover filme"
                title="Remover filme"
                onClick={() => handleRemoverFilme(f.id)}
              >
                <Trash2 className="h-4 w-4"/>
              </Button>
              <Button 
                disabled={carregando}
                size={'sm'}
                aria-label="Editar filme"
                title="Editar filme"
                onClick={() => props.editarFilme(f)}
              >
                <Pencil className="h-4 w-4"/>
              </Button>
            </div>
          ])}
        />
      )}
    </div>
  );
};
