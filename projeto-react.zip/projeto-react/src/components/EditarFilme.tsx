import axios from "axios";
import * as z from "zod";

import { Input } from "./ui/Input";
import { Button } from "./ui/Button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "./ui/Form";
import { useToast } from "./ui/use-toast";

const formSchema = z.object({
  titulo: z
    .string({
      required_error: "O título é obrigatório",
    })
    .min(1, "O título é obrigatório")
    .max(50, "O título deve ter no máximo 50 caracteres"),
  ator: z
    .string({
      required_error: "O ator é obrigatório",
    })
    .min(1, "O ator é obrigatório")
    .max(50, "O ator deve ter no máximo 50 caracteres"),
  faixaEtaria: z
    .coerce
    .number({
      required_error: "A faixa etária é obrigatória",
    })
    .min(0, "A faixa etária deve ser entre 0 e 18")
    .max(18, "A faixa etária deve ser entre 0 e 18"),
  genero: z
    .string({
      required_error: "O gênero é obrigatório",
    })
    .min(1, "O gênero é obrigatório")
    .max(50, "O gênero deve ter no máximo 50 caracteres"),
});

interface Props {
  id: number;
  defaultValues: z.infer<typeof formSchema>;
  fecharMenu: () => void;
}

export const EditarFilme = (props: Props) => {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: props.defaultValues,
  });
  const { toast } = useToast()

  const editarFilme = async (values: z.infer<typeof formSchema>) => {
    try {
      await axios.put(`http://localhost:5000/filmes/${props.id}`, values);
      toast({
        title: 'Filme editado com sucesso!',
      })
    } catch (error) {
      console.error("Erro ao adicionar filme:", error);
      toast({
        title: 'Erro ao editar filme',
        description: 'Verifique o console para mais detalhes.',
        variant: 'destructive',
      })
    }
    props.fecharMenu();
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(editarFilme)} className="space-y-2">
        <FormField
          control={form.control}
          name="titulo"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Título</FormLabel>
              <FormControl>
                <Input placeholder="Uma Noite no Museu 2" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="ator"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Ator</FormLabel>
              <FormControl>
                <Input placeholder="Ben Stiller" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="faixaEtaria"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Ator</FormLabel>
              <FormControl>
                <Input type="number" placeholder="12" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="genero"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Ator</FormLabel>
              <FormControl>
                <Input placeholder="Aventura" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="pt-4">
          <Button type="submit">Editar</Button>
        </div>
      </form>
    </Form>
  );
};
