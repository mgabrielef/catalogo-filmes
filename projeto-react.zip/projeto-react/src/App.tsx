import "./App.css";
import { ListarFilmes } from "./components/ListarFilmes";
import { AdicionarFilme } from "./components/AdicionarFilme";
import { useState } from "react";
import { EditarFilme } from "./components/EditarFilme";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./components/ui/Dialog";
import { Button } from "./components/ui/Button";
import { Toaster } from "./components/ui/Toaster";
import axios from "axios";

export type Filme = {
  id: number;
  titulo: string;
  ator: string;
  faixaEtaria: number;
  genero: string;
};

function App() {
  const [filmes, setFilmes] = useState<Filme[]>([]);
  const [menuAdicionarFilme, setMenuAdicionarFilme] = useState(false);
  const [menuEditarFilme, setMenuEditarFilme] = useState(false);
  const [filmeSelecionado, setFilmeSelecionado] = useState<Filme | null>(null);

  async function carregarFilmes() {
    try {
      const response = await axios.get("http://localhost:5000/filmes");
      setFilmes(response.data.filme);
    } catch (error) {
      console.error("Erro ao carregar filmes:", error);
    }
  }

  function editarFilme(filme: Filme) {
    setFilmeSelecionado(filme);
    setMenuEditarFilme(true);
  }

  function fecharMenuAdicionarFilme() {
    setMenuAdicionarFilme(false);
    carregarFilmes();
  }

  function fecharMenuEditarFilme() {
    setMenuEditarFilme(false);
    carregarFilmes();
  }

  return (
    <div className="w-full max-w-[1024px] p-4 px-6 mx-auto">
      <main className="flex flex-col items-center justify-center gap-6">
        <ListarFilmes
          carregarFilmes={carregarFilmes}
          filmes={filmes}
          editarFilme={editarFilme}
        />

        <Dialog open={menuAdicionarFilme} onOpenChange={setMenuAdicionarFilme}>
          <DialogTrigger asChild>
            <Button>
              Adicionar novo filme
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar um novo filme</DialogTitle>
            </DialogHeader>
            <AdicionarFilme fecharMenu={fecharMenuAdicionarFilme} />
          </DialogContent>
        </Dialog>

        <Dialog open={menuEditarFilme} onOpenChange={setMenuEditarFilme}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar filme</DialogTitle>
            </DialogHeader>
            {filmeSelecionado && (
              <EditarFilme 
                defaultValues={{
                  ator: filmeSelecionado.ator,
                  faixaEtaria: filmeSelecionado.faixaEtaria,
                  genero: filmeSelecionado.genero,
                  titulo: filmeSelecionado.titulo,
                }} 
                id={filmeSelecionado.id}
                fecharMenu={fecharMenuEditarFilme}
              />
            )}
          </DialogContent>
        </Dialog>
      </main>

      <Toaster />
    </div>
  );
}

export default App;
